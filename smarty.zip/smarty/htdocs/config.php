<?php
    // Credentials to connect to the database
    
    $host = "localhost";
    $db_username = "root";
    $db_pw = "";
    $dbname = "bike_shop";
?>