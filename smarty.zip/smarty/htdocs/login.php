<?php
    // Validates the login
 require('Smarty.class.php');

  $smarty = new Smarty;

  $smarty->template_dir = 'C:/wamp/www/smarty/htdocs/smarty/templates';
  $smarty->config_dir = 'C:/wamp/www/smarty/htdocs/smarty/configs';
  $smarty->cache_dir = 'C:/wamp/www/smarty/cache';
  $smarty->compile_dir = 'C:/wamp/www/smarty/templates_c';
  
require('connection.php');

$username = $_POST["username"];
$pw = $_POST["password"];
$head=<<<EOT
<head>
        <title>Inventory Management System</title>
        <style type="text/css">
            body{
                text-align: left;
            }
         .content {text-align: center;}
        </style>
    </head>
EOT;
$content= "<div class = \"content\">Welcome " . $username  . "</div>";
$leftnav="<ul><li><a href=\"getPart.php\"> Get Part </a><li><li><a href=\"getProduct.php\"> Get Product </a><li> </ul> ";
$smarty->assign('content',$content);
$smarty->assign('head',$head);
$smarty->assign('leftnav',$leftnav);
$smarty->display('page.tpl');

?>