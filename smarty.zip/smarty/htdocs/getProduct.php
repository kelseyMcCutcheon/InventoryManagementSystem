<?php
require('connection.php');

 require('Smarty.class.php');

  $smarty = new Smarty;

  $smarty->template_dir = 'C:/wamp/www/smarty/htdocs/smarty/templates';
  $smarty->config_dir = 'C:/wamp/www/smarty/htdocs/smarty/configs';
  $smarty->cache_dir = 'C:/wamp/www/smarty/cache';
  $smarty->compile_dir = 'C:/wamp/www/smarty/templates_c';

$head=<<<EOT
<head>
        <title>Inventory Management System</title>
        <style type="text/css">
            body{
                text-align: left;
            }
         .content {text-align: center;}
        </style>
    </head>
EOT;

$connection = db_connect();

$sql = "SELECT part_name from parts";

$result = mysqli_query($connection, $sql);
// go to database
//get a list of products
//create a dropdown
$x = "";
if ($result != false) {
    $x .= '<label for="parts">Choose a part:</label>';
    $x .= '<select name="parts" id="parts">';
    while($row = mysqli_fetch_assoc($result)) {
        $x .= "<option value=" . $row["part_name"] . ">" . $row["part_name"] . "</option>";
    }
  
$x .= "</select>";
}

$content= "<div class = \"content\">" .$x . "</div>";




$leftnav="<ul><li><a href=\"getPart.php\"> Get Part </a><li><li><a href=\"getProduct.php\"> Get Product </a><li> </ul> ";
$smarty->assign('content',$content);
$smarty->assign('head',$head);
$smarty->assign('leftnav',$leftnav);
$smarty->display('page.tpl');
?>