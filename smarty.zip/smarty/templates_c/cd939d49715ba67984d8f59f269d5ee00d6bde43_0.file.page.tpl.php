<?php
/* Smarty version 3.1.39, created on 2021-04-15 20:15:21
  from 'C:\wamp\www\smarty\htdocs\smarty\templates\page.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_60789ed9170c28_15895804',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cd939d49715ba67984d8f59f269d5ee00d6bde43' => 
    array (
      0 => 'C:\\wamp\\www\\smarty\\htdocs\\smarty\\templates\\page.tpl',
      1 => 1618514706,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60789ed9170c28_15895804 (Smarty_Internal_Template $_smarty_tpl) {
?><html>
    <?php echo $_smarty_tpl->tpl_vars['head']->value;?>

<body>
<?php echo $_smarty_tpl->tpl_vars['leftnav']->value;?>

<?php echo $_smarty_tpl->tpl_vars['content']->value;?>

</body>
</html>
<?php }
}
