<?php
/* Smarty version 3.1.39, created on 2021-04-12 14:51:51
  from 'C:\wamp\www\smarty\htdocs\smarty\templates\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_60745e870b0625_47464428',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '98541b34425e8f39834655c54ac2ba704190cab3' => 
    array (
      0 => 'C:\\wamp\\www\\smarty\\htdocs\\smarty\\templates\\index.tpl',
      1 => 1618238858,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60745e870b0625_47464428 (Smarty_Internal_Template $_smarty_tpl) {
?><html>
  <body>
    Hello, <?php echo $_smarty_tpl->tpl_vars['name']->value;?>
!
  </body>
</html><?php }
}
